#!/bin/bash

java -jar CMDBSyncTool.jar $*
